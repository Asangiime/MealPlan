import React from 'react';

import './pescatarian.css';  
const Pescatarian: React.FC = () => {
  return (
    <div>
      <h2>Pescatarian Menu</h2>
      <p>Delight in our pescatarian meal selections.</p>
      {/* Add more pescatarian meal details here */}
    </div>
  );
};

export default Pescatarian;