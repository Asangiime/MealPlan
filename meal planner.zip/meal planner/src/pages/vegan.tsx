import React from 'react';
import './vegan.css';  
const Vegan : React.FC = () => {
  return (
    <div>
      <h2>Vegan Menu</h2>
      <p>Explore our delicious vegan meal options.</p>
      {/* Add more vegan meal details here */}
    </div>
  );
};

export default Vegan;
